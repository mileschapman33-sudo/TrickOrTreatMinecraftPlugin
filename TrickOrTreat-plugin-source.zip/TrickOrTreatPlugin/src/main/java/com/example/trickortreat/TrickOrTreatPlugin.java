package com.example.trickortreat;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class TrickOrTreatPlugin extends JavaPlugin implements Listener {

    private boolean roundActive = false;
    private final Set<UUID> entrants = new HashSet<>();
    private int intervalMinutes;
    private int windowSeconds;
    private double treatChance; // 0.0 - 1.0
    private String broadcastMsg;
    private String joinMsg;
    private String noEntrantsMsg;
    private String pickingMsg;
    private String treatTitle;
    private String trickTitle;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfig();
        getServer().getPluginManager().registerEvents(this, this);
        startRepeatingEvent();
        getLogger().info("TrickOrTreat enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("TrickOrTreat disabled!");
    }

    private void loadConfig() {
        getConfig().addDefault("interval_minutes", 8);
        getConfig().addDefault("window_seconds", 15);
        getConfig().addDefault("treat_chance", 0.6);
        getConfig().addDefault("messages.broadcast", "🎃 Trick Or Treat! Type §eKnock§r in chat in the next §b{window}s§r to enter!");
        getConfig().addDefault("messages.join", "🛎 {player} knocked on the door!");
        getConfig().addDefault("messages.no_entrants", "😴 No one knocked. Maybe next time!");
        getConfig().addDefault("messages.picking", "🔔 Time's up! Picking a random visitor...");
        getConfig().addDefault("messages.treat_title", "🍬 TREAT!");
        getConfig().addDefault("messages.trick_title", "👻 TRICK!");
        getConfig().options().copyDefaults(true);
        saveConfig();

        intervalMinutes = Math.max(1, getConfig().getInt("interval_minutes"));
        windowSeconds = Math.max(5, getConfig().getInt("window_seconds"));
        treatChance = Math.min(1.0, Math.max(0.0, getConfig().getDouble("treat_chance")));
        broadcastMsg = getConfig().getString("messages.broadcast");
        joinMsg = getConfig().getString("messages.join");
        reloadMessages();
    }

    private void reloadMessages() {
        noEntrantsMsg = getConfig().getString("messages.no_entrants");
        pickingMsg = getConfig().getString("messages.picking");
        treatTitle = getConfig().getString("messages.treat_title");
        trickTitle = getConfig().getString("messages.trick_title");
    }

    private void startRepeatingEvent() {
        long periodTicks = intervalMinutes * 60L * 20L;
        new BukkitRunnable() {
            @Override
            public void run() {
                if (roundActive) return;
                beginRound();
            }
        }.runTaskTimer(this, 20L, periodTicks);
    }

    private void beginRound() {
        if (Bukkit.getOnlinePlayers().isEmpty()) return;

        roundActive = true;
        entrants.clear();

        String msg = broadcastMsg.replace("{window}", String.valueOf(windowSeconds));
        Bukkit.broadcastMessage(colorize(msg));
        Bukkit.getOnlinePlayers().forEach(p ->
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_YES, 0.7f, 1.2f));

        new BukkitRunnable() {
            @Override
            public void run() {
                closeAndDraw();
            }
        }.runTaskLater(TrickOrTreatPlugin.this, windowSeconds * 20L);
    }

    private void closeAndDraw() {
        Bukkit.broadcastMessage(colorize(pickingMsg));
        List<Player> pool = entrants.stream()
                .map(Bukkit::getPlayer)
                .filter(Objects::nonNull)
                .filter(Player::isOnline)
                .collect(Collectors.toList());

        if (pool.isEmpty()) {
            Bukkit.broadcastMessage(colorize(noEntrantsMsg));
            roundActive = false;
            return;
        }

        Player winner = pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
        boolean isTreat = ThreadLocalRandom.current().nextDouble() < treatChance;

        if (isTreat) giveTreat(winner);
        else giveTrick(winner);

        roundActive = false;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        if (!roundActive) return;

        String content = e.getMessage();
        if (content.equalsIgnoreCase("knock")) {
            boolean added = entrants.add(e.getPlayer().getUniqueId());
            e.setCancelled(true);

            if (added) {
                String msg = joinMsg.replace("{player}", e.getPlayer().getName());
                Bukkit.getScheduler().runTask(this, () -> {
                    Bukkit.broadcastMessage(colorize(msg));
                    e.getPlayer().playSound(e.getPlayer().getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1.4f);
                });
            }
        }
    }

    private void giveTreat(Player p) {
        p.sendTitle(colorize(treatTitle), "Happy Halloween!", 10, 50, 10);
        p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);

        int roll = rnd(1, 6);
        ItemStack reward = null;

        switch (roll) {
            case 1 -> reward = new ItemStack(Material.DIAMOND, rnd(3, 8));
            case 2 -> reward = enchantedItem(randomArmorPiece(), Map.of(
                    Enchantment.PROTECTION, rnd(2, 4),
                    Enchantment.UNBREAKING, rnd(2, 3)
            ));
            case 3 -> reward = enchantedItem(Material.DIAMOND_SWORD, Map.of(
                    Enchantment.SHARPNESS, rnd(2, 5),
                    Enchantment.UNBREAKING, rnd(2, 3),
                    Enchantment.MENDING, 1
            ));
            case 4 -> reward = enchantedItem(Material.DIAMOND_PICKAXE, Map.of(
                    Enchantment.EFFICIENCY, rnd(3, 5),
                    Enchantment.UNBREAKING, rnd(2, 3),
                    Enchantment.MENDING, 1
            ));
            case 5 -> reward = new ItemStack(Material.TOTEM_OF_UNDYING, 1);
            case 6 -> reward = new ItemStack(Material.NETHERITE_INGOT, rnd(1, 2));
        }

        if (ThreadLocalRandom.current().nextDouble() < 0.25) {
            p.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, rnd(1, 3)));
        }

        if (reward != null) {
            nameIfWanted(reward, "Halloween Treat");
            p.getInventory().addItem(reward);
        }
        Bukkit.broadcastMessage(colorize("🍬 " + p.getName() + " got a sweet treat!"));
    }

    private void giveTrick(Player p) {
        p.sendTitle(colorize(trickTitle), "Better luck next time...", 10, 50, 10);
        p.playSound(p.getLocation(), Sound.ENTITY_PHANTOM_AMBIENT, 1f, 0.5f);

        int roll = rnd(1, 6);
        switch (roll) {
            case 1 -> p.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, 20 * rnd(20, 40), 1, true, true, true));
            case 2 -> p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 20 * rnd(8, 16), 1, true, true, true));
            case 3 -> p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * rnd(10, 20), 0, true, true, true));
            case 4 -> p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 20 * rnd(15, 30), 1, true, true, true));
            case 5 -> p.setFoodLevel(Math.min(2, p.getFoodLevel()));
            case 6 -> {
                World w = p.getWorld();
                w.strikeLightningEffect(p.getLocation());
                p.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 20 * rnd(8, 16), 0, true, true, true));
            }
        }

        p.getInventory().addItem(named(new ItemStack(Material.ROTTEN_FLESH, rnd(3, 8)), "Soggy Candy"));
        Bukkit.broadcastMessage(colorize("👻 " + p.getName() + " got tricked!"));
    }

    private static int rnd(int min, int max) {
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    private static String colorize(String s) {
        return s == null ? "" : s.replace("&", "§");
    }

    private static Material randomArmorPiece() {
        Material[] armor = new Material[] {
                Material.DIAMOND_HELMET,
                Material.DIAMOND_CHESTPLATE,
                Material.DIAMOND_LEGGINGS,
                Material.DIAMOND_BOOTS
        };
        return armor[ThreadLocalRandom.current().nextInt(armor.length)];
    }

    private static ItemStack enchantedItem(Material mat, Map<Enchantment, Integer> enchants) {
        ItemStack item = new ItemStack(mat, 1);
        return enchantedItem(item, enchants);
    }

    private static ItemStack enchantedItem(ItemStack item, Map<Enchantment, Integer> enchants) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§dHalloween Treat");
            item.setItemMeta(meta);
        }
        enchants.forEach((ench, lvl) -> {
            try {
                item.addUnsafeEnchantment(ench, lvl);
            } catch (Exception ignored) {}
        });
        return item;
    }

    private static void nameIfWanted(ItemStack item, String displayName) {
        if (displayName == null || displayName.isEmpty()) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.setDisplayName("§d" + displayName);
        item.setItemMeta(meta);
    }

    private static ItemStack named(ItemStack item, String displayName) {
        nameIfWanted(item, displayName);
        return item;
    }
}
